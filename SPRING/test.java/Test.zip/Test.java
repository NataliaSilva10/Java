public class Test {
    public static void main(String[] args){
    System.out.println("My name is Natalia");
    System.out.println("I am 24 yo");
    System.out.println("My hometown is Brazil!");
    }
}