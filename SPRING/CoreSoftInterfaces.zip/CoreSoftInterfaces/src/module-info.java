/**
 * 
 */
/**
 * @author Natalia
 *
 */
module CoreSoftInterfaces {
	requires java.sql;
}