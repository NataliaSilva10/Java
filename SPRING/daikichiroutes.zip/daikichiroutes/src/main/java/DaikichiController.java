
public class DaikichiController {

}
